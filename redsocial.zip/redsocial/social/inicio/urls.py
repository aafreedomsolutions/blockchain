from sys import implementation
from django.conf import settings
from django.urls import path
from . import views
from django.conf.urls.static import static
from django.contrib.auth.views import LoginView, LogoutView


app_name='inicio'

urlpatterns=[
    path('', views.index, name='index'),
    path('registro/', views.registro, name='registro'),
    path('login/', LoginView.as_view(template_name='social/login.html'), name='login'),
    path('logout/', LogoutView.as_view(template_name='social/logout.html'), name='logout'),
    path('post/', views.post, name='post'),
    path('perfil/', views.profile, name='profile'),
    path('perfil/<str:username>/', views.profile, name='profile'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

