from dataclasses import field
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from inicio.models import Post

class UserRegisterForm(UserCreationForm):
    #email = forms.EmailField()
    #image = forms.ImageField(label='Coloca una imagen para el perfil')
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Confirmar Contraseña', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username','password1', 'password2']
        help_text = { m:"" for m in fields }

class PostForm(forms.ModelForm):
    content = forms.CharField(label='', widget=forms.Textarea(attrs={'rows':2, 'placeholder': '¿Qué quieres publicar?'}), required=True)

    class Meta:
        model = Post
        fields = ['content']