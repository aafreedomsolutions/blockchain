from django.contrib import admin
from .models import Perfil, Post

admin.site.register(Perfil)
admin.site.register(Post)

