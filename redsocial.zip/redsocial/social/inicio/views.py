from django.shortcuts import get_object_or_404, redirect, render
from django.template import Template
from .models import *
from django.template import RequestContext
from .forms import UserRegisterForm, PostForm
from django.contrib import messages
from django.contrib.auth.models import User


def index(request):
    posts = Post.objects.all()
    context = {'posts': posts}
    return render(request, 'inicio/feed.html', context)

def registro(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            messages.success(request, f'Usuario {username} creado con éxito!!')
            return redirect('inicio:index')
    else:
        form = UserRegisterForm()
    context = {'form':form}
    return render(request, 'inicio/register.html', context)

def post(request):
    usuario_actual = get_object_or_404(User, pk=request.user.pk)
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = usuario_actual
            post.save()
            messages.success(request, 'El Post fue agregado de forma correcta!!!!')
            return redirect('inicio:index')
    else:
        form =PostForm()
    return render(request, 'inicio/post.html', {'form': form})


def profile(request, username=None):
    usuario_actual = request.user
    if username and username != usuario_actual.username:
        user = User.objects.get(username=username)
        posts = user.posts.all()
    else:
        posts = usuario_actual.posts.all()
        user = usuario_actual
    context = {'user':user, 'post':posts}
    return render(request, 'inicio/profile.html', context)